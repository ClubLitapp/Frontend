import React from 'react';
import HomeScreen from './components/screens/HomeScreen';
import ReviewScreen from './components/screens/ReviewScreen';
import DetailsScreen from './components/screens/DetailsScreen';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import NavigationBar from './components/screen-components/General-Navigation';
import { StyleSheet, View } from 'react-native';

const Stack = createNativeStackNavigator();

const styles = StyleSheet.create({
  navigator:{
    height: '100%',
  }, 
  navContainer:{
    height: '100%',
    flexDirection: 'column',
    justifyContent: 'flex-end'
  },

})
const App = () => {
  return (
    <View style={styles.navigator}>
      <NavigationContainer style={styles.navContainer}>
          <Stack.Navigator screenOptions={{ headerShown: false }} styles={styles.navigator}>
            <Stack.Screen name="Home" component={HomeScreen} />
            <Stack.Screen name="Details" component={DetailsScreen} />
            <Stack.Screen name="Review" component={ReviewScreen} />
          </Stack.Navigator>
        </NavigationContainer>
        <NavigationBar/>
    </View>
      
  );
  
}
export default App;