import React, {useState} from 'react'
import {View, StatusBar, Text, Image, TextInput, Pressable, TouchableHighlight, PermissionsAndroid} from 'react-native'
import Slider from '@react-native-community/slider'
import { StyleSheet } from 'react-native';
import {LinearGradient} from 'expo-linear-gradient'

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#000000",
        flex: 1,
        paddingRight: 15, paddingLeft: 15,
        paddingTop: 25
    },
    header: {
        height: 70,
        flexDirection: 'row',
        justifyContent: "space-between",
        color: "black"
    },
    club: {
        paddingTop: 15,
        flex: 0.66,
    },
    icon:{
        paddingTop: 25,
    
    },
    clubText: {
        color: 'white',
        fontSize: 50
    },
    appIcon:{
        height: 50,
        width: 100,
        resizeMode: 'contain'
    },
    litnessView:{
        marginTop: 16,
        // paddingHorizontal: 16,
        // marginHorizontal: -16,
        flex: 1, 
        justifyContent: 'center',
        flexDirection: 'row',
    },
    litnessSlider:{
        zIndex: 1,
        flex: 1
    },
    litnessGradinetHolder:{
        marginHorizontal: 10,
        width: '91%',
        position: 'absolute',
        alignSelf: 'center',
        height: 10,
    },
    litnessGradient:{
        position: 'absolute',
        left: 0,
        alignSelf: 'center',
        height: 10,
        borderRadius: 15,
        zIndex: -1
    },
    litnessThumb:{
        position: 'absolute',
        left: '1.75%',
        alignSelf: 'center',
        height: 25,
        width: 25,
        backgroundColor: 'white',
        borderRadius: 50,
        zIndex: 0
    },
    mediaView:{
        height: 'auto',
        width: 'auto',
        flexDirection: 'row',
        marginBottom: 16
    },
    mediaUploadButton:{
        borderStyle: 'dashed',
        borderColor: '#545454',
        borderWidth: 1,
        borderRadius: 20,
        height: 100,
        width: 100,
        backgroundColor: '#1F1F1F',
        marginRight: 16,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    mediaUploadButtomAdd:{
        height: 40,
        width: 40,
        tintColor: '#545454'
    },
    descriptionView:{
        height: 'auto',
        backgroundColor: '#1F1F1F',
        borderWidth: 0.5,
        borderColor: '#545454',
        borderRadius: 20,
        padding: 15,
        marginBottom: 16
    },
    contentHeader:{
        marginVertical: 16,
        color: 'white',
        fontSize: 20,
        fontWeight: 'bold'
    },
    descriptionTextInput:{
        height: 200,
        textAlignVertical: 'top',
        color: 'white'
    },
    submissionView:{
        flexDirection: 'row',
        flex: 1,
        justifyContent: 'flex-end',
    },
    submissionButton:{
        marginVertical: 16,
        height: 50,
        width: 150,
        borderRadius: 50,
        flexDirection: 'column'
    },
    submissionButtonText:{
        alignSelf: 'center',
        width: 'auto',
        height: 'auto',
        color: 'white',
        flex: 1,
        fontSize: 16,
        textAlignVertical: 'center'
    }
    });

const ReviewScreen = ({ navigation }) => {
    const [sliderValue, setSliderValue] = useState(100);


    const handleSliderChange = (value) => {
      setSliderValue(Math.round(value));
    };

    return (<View style={styles.container}>
        <StatusBar style='light'></StatusBar>
        <View style={styles.header}>
          <View style={styles.club}><Text style={styles.clubText}>Miami</Text></View>
          <View style={styles.icon}><Image style={styles.appIcon} source={require('../../assets/clublit.png')} /></View>
        </View>
        <View style={styles.litnessView}>
            <Slider
                style={styles.litnessSlider}
                minimumValue={0}
                maximumValue={5}
                step={0.25}
                value={sliderValue}
                onValueChange={(value) => {handleSliderChange(20 * value)}}
                minimumTrackTintColor='transparent'
                maximumTrackTintColor="transparent"
                thumbTintColor='transparent'
            />
            <View style={styles.litnessGradinetHolder}>
                <LinearGradient colors={['#9B1881', '#7224B5', '#4930EC']} start={[1, 0]} style={[styles.litnessGradient, {width: sliderValue + '%'}]}></LinearGradient>
            </View>
            <View style={[styles.litnessThumb, {left: (1 + (sliderValue/100) * 90.25) + '%'}]}></View>
            
        </View>
        <Text style={styles.contentHeader}>Take a Pic!</Text>
        <View style={styles.mediaView}>
            <TouchableHighlight onPress={()=>{}}>
                <View style={styles.mediaUploadButton}>
                    <Image style={styles.mediaUploadButtomAdd} source={require('../../assets/add.png')}></Image>
                </View>
            </TouchableHighlight>
            <TouchableHighlight onPress={()=>{}}>
                <View style={styles.mediaUploadButton}>
                    <Image style={styles.mediaUploadButtomAdd} source={require('../../assets/add.png')}></Image>
                </View>
            </TouchableHighlight>
        </View>
        <Text style={styles.contentHeader}>Comment</Text>
        <View style={styles.descriptionView}>
            <TextInput style={styles.descriptionTextInput} placeholder='Make a comment about this location...' placeholderTextColor='#BDBDBD' multiline={true}/>
        </View>
        <View style={styles.submissionView}>
            <TouchableHighlight
             onPress={() => navigation.navigate('Home')}>
            <LinearGradient
                  colors={['#9B1881', '#7224B5', '#4930EC']}
                  start={[1, 0]}
                  style={styles.submissionButton}><Text style={styles.submissionButtonText}>Submit Rating</Text></LinearGradient></TouchableHighlight>
        </View>
        
      </View>)
  }

export default ReviewScreen