import React from 'react'
import {View, StatusBar, Text, Image, TextInput, FlatList, StyleSheet} from 'react-native'
import Item from '../screen-components/HomeScreen-Item';
import Header from '../screen-components/General-Header';
import { useState } from 'react';
import Stories from '../screen-components/HomeScreen-Stories';
import {FlashList} from '@shopify/flash-list'

const FILTERS = [
  {
    id: 0,
    type: 'Open',
    enabled: true
  }
]


const DATA = [
    {
      type: 'Header',
    },
    {
      type: 'Stories',
    },
    {
      id: '1',
      title: 'Else',
      rating: 4.9,
      image: '../../assets/image.jpg'
    },

    {
      id: '3',
      title: 'SHOTS Bar Miami',
      rating: 3.9,
      image: '../../assets/image.jpg'
    },
    {
      id: '4',
      title: 'Brick',
      rating: 3.7,
      image: '../../assets/image.jpg'
    },
    {
      id: '5',
      title: 'Tucandela Bar',
      rating: 3.5,
      image: '../../assets/image.jpg'
    },
    {
      id: '6',
      title: 'Club Space',
      rating: 3.4,
      image: '../../assets/image.jpg'
    },
    {
      id: '7',
      title: 'Studio Sixty',
      rating: 3.4,
      image: '../../assets/image.jpg'
    },
    {
      type: 'Spacer'
    }
];

const styles = StyleSheet.create({
container: {
    backgroundColor: "#000000",
    flex: 1,
    padding: 16
},
header: {
    height: 70,
    flexDirection: 'row',
    justifyContent: "space-between",
    color: "black"
},
location: {
    paddingTop: 15,
    flex: 0.66,
},
icon:{
    paddingTop: 25,

},
locationText: {
    color: 'white',
    fontSize: 50
},
itemList: {

},
filterList: {
  height: 56
},
searchView: {
    paddingTop: 25,
    paddingBottom: 15,
},
searchBar: {
    height: 40, 
    borderRadius: 7.5,
    borderColor: "white",
    borderWidth: 0.01,
    backgroundColor: '#1F1F1F',
    color: 'white',
    paddingLeft: 15,
},
mainDescriptorView: {
    height: 25,
},
mainDescriptor: {
    color: 'white',
    fontWeight: 'bold',
},
appIcon:{
    height: 50,
    width: 100,
    resizeMode: 'contain'
},
});

const HomeScreen = ({ navigation }) => {
    return (
      <View style={styles.container}>
        <StatusBar style='light'></StatusBar>        
        <FlashList
            data={DATA}
            renderItem={({ item }) => {
              if(item.type == "Header"){
                return <Header name="Miami"/>
              } else if(item.type == "Stories"){
                return <Stories onPress={(id)=>{navigation.navigate('Details')}}/>
              } else if (item.type == "Spacer") {
                return <View style={{height: 40}} />
              } else {
                return <Item title={item.title} rating={item.rating} image={item.image} onPress={() => navigation.navigate('Details')}/>
              }
            }
          }
            estimatedItemSize={200}
            ItemSeparatorComponent={() => <View style={{height: 40}} />}
          />
      </View>
    );
  };

export default HomeScreen