import React from 'react'
import {View, StatusBar, Image, Text, Dimensions, TouchableHighlight } from 'react-native'
import { StyleSheet } from 'react-native';
import {LinearGradient} from 'expo-linear-gradient'
import Header from '../screen-components/General-Header';
import Carousel from 'react-native-snap-carousel';
import PagerView from 'react-native-pager-view';

const phoneWidth = Dimensions.get('window').width; // Get device width

const styles = StyleSheet.create({
    container: {
        backgroundColor: "white",
        flex: 1,
    },
    subheader: {
        marginTop: 16,
        height: 32,
        flexDirection: "row",
    },
    subheaderDirectionHolder:{
        flex: 0.5,
        backgroundColor: 'red',
        flexDirection: 'row',
        alignContent: 'flex-start'
    },
    subheaderLitnessHolder: {
        flex: 0.5,
        flexDirection: 'row',
        alignContent: 'flex-end'
    },
    litnessView:{
        marginTop: 16,
        // paddingHorizontal: 16,
        // marginHorizontal: -16,
        flex: 1, 
        justifyContent: 'center',
        flexDirection: 'row',
    },
    litnessSlider:{
        zIndex: 1,
        flex: 1
    },
    litnessGradinetHolder:{
        marginHorizontal: 10,
        width: '91%',
        position: 'absolute',
        alignSelf: 'center',
        height: 10,
    },
    litnessGradient:{
        position: 'absolute',
        left: 0,
        alignSelf: 'center',
        height: 10,
        borderRadius: 15,
        zIndex: -1
    },
    litnessThumb:{
        position: 'absolute',
        left: '1.75%',
        alignSelf: 'center',
        height: 25,
        width: 25,
        backgroundColor: 'white',
        borderRadius: 50,
        zIndex: 0
    },
    mediaView:{
        height: 'auto',
        width: 'auto',
        flexDirection: 'row',
        marginBottom: 16
    },
    mediaUploadButton:{
        borderStyle: 'dashed',
        borderColor: '#545454',
        borderWidth: 1,
        borderRadius: 20,
        height: 100,
        width: 100,
        backgroundColor: '#1F1F1F',
        marginRight: 16,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    mediaUploadButtomAdd:{
        height: 40,
        width: 40,
        tintColor: '#545454'
    },
    descriptionView:{
        height: 'auto',
        backgroundColor: '#1F1F1F',
        borderWidth: 0.5,
        borderColor: '#545454',
        borderRadius: 20,
        padding: 15,
        marginBottom: 16
    },
    contentHeader:{
        marginVertical: 16,
        color: 'white',
        fontSize: 20,
        fontWeight: 'bold'
    },
    descriptionTextInput:{
        height: 200,
        textAlignVertical: 'top',
        color: 'white'
    },
    submissionView:{
        flexDirection: 'row',
        flex: 1,
        justifyContent: 'flex-end',
    },
    submissionButton:{
        marginVertical: 16,
        height: 50,
        width: 150,
        borderRadius: 50,
        flexDirection: 'column'
    },
    submissionButtonText:{
        alignSelf: 'center',
        width: 'auto',
        height: 'auto',
        color: 'white',
        flex: 1,
        fontSize: 16,
        textAlignVertical: 'center'
    },
    image:{
        height: '100%',
        width: '100%',
        resizeMode: 'cover',
    },
    carouselHolder:{
        alignSelf: 'center',
        marginTop: 24,
        height: 560
    },
    pagerHolder: {
        height: 256,
        width: '100%',
        backgroundColor: 'red',
      },
    pagerView: {
        height: 256,
        zIndex: -1
    },
    detailsView:{
        top: 224,
        height: '100%',
        width: '100%',
        position: 'absolute',
        alignSelf: 'baseline',
        backgroundColor: 'black',
        borderRadius: 32
    },
    hoursView:{
        height: 80,
        width: 'auto',
        margin: 16,
        borderTopLeftRadius: 32,
        borderTopRightRadius: 32,
        borderBottomLeftRadius: 16,
        borderBottomRightRadius: 16,
        borderStyle: 'dashed',
        borderWidth: 2,
        borderColor: 'grey',
        flexDirection: 'column',
        padding: 8
    },
    openStatusText:{
        color: 'lightgreen',
        textAlignVertical: 'top',
        fontWeight: 'bold',
        fontSize: 20,
        alignSelf: 'center'
    },
    openTimesText:{
        color: 'white',
        textAlignVertical: 'top',
        fontWeight: 'bold',
        fontSize: 16,
        alignSelf: 'center'
    },
    buttonRow:{
        paddingHorizontal: 16,
        width: '100%',
        height: 56,
        flexDirection: 'row',
        justifyContent: 'space-evenly'
    },
    button:{
        height: 56,
        flex: 1,
        borderRadius: 40,
        backgroundColor: 'grey',
        justifyContent: 'center'
    },
    spacer:{
        width:16,
    },
    clubData:{
        top: -48,
        position: 'absolute',
        width: '100%',
        height: 48,
        paddingHorizontal: 32,
        flexDirection: 'row'

    },
    clubName:{
        fontWeight: 'bold',
        color: 'white',
        textAlignVertical: 'top',
        fontSize: 32,
        marginRight: 8,
        alignSelf: 'flex-start'
    },
    litnessGraphic: {
        borderRadius: 5,
        width: 32,
        flexDirection: 'column'
    },
    litnessRating: {
        fontWeight: 'bold',
        color: 'white',
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: 16
    },
    clubLitnessSection:{
        flexDirection: 'row',
        alignSelf: 'center'
    },
    clubRow:{
        height: 48,
        width: '100%',
        paddingHorizontal: 16,
        flexDirection: 'row'
    },
    reviewButton:{
        height: 48,
        flex: 1,
        borderRadius: 16,
        backgroundColor: 'purple',
        flexDirection: 'column',
        justifyContent: 'center'
    },
    directionsButton:{
        height: 48,
        flex: 1,
        borderRadius: 16,
        backgroundColor: '#1F1F1F',
        flexDirection: 'column',
        justifyContent: 'center'
    },
    spacer:{
        width: 16,
    },
    buttonText:{
        fontWeight: 'bold',
        color: 'white',
        textAlignVertical: 'center',
        fontSize: 20,
        alignSelf: 'center'
    },
    });
const DetailsScreen = ({ navigation }) => {
    const data = [
        { title: 'Image 1', caption: 'Beautiful landscape', url: 'https://example.com/image1.jpg' },
        { title: 'Image 2', caption: 'Stunning sunset', url: 'https://example.com/image2.jpg' },
        { title: 'Image 1', caption: 'Beautiful landscape', url: 'https://example.com/image1.jpg' },
        { title: 'Image 2', caption: 'Stunning sunset', url: 'https://example.com/image2.jpg' },
        { title: 'Image 1', caption: 'Beautiful landscape', url: 'https://example.com/image1.jpg' },
        { title: 'Image 2', caption: 'Stunning sunset', url: 'https://example.com/image2.jpg' },
        { title: 'Image 1', caption: 'Beautiful landscape', url: 'https://example.com/image1.jpg' },
        { title: 'Image 2', caption: 'Stunning sunset', url: 'https://example.com/image2.jpg' },
        { title: 'Image 1', caption: 'Beautiful landscape', url: 'https://example.com/image1.jpg' },
        { title: 'Image 2', caption: 'Stunning sunset', url: 'https://example.com/image2.jpg' },
        // Add more images as needed
      ];
    
      const renderItem = ({ item }) => (
        <View style={styles.slide}>
          <Image source={require('../../assets/image.jpg')} style={styles.image} resizeMode="cover" />
          <Text style={styles.title}>{item.title}</Text>
        </View>
      );
    return (
        <View style={styles.container}>
            <View style={styles.pagerHolder}>
                <PagerView style={styles.pagerView} initialPage={0}>
                    <View key="1">
                        <Image style={styles.image} source={require('../../assets/image.jpg')}/>
                    </View>
                    <View key="2">
                        <Image style={styles.image} source={require('../../assets/image.jpg')}/>
                    </View>
                </PagerView>
            </View>
            <View style={styles.detailsView}>
                <View style={styles.clubData}>
                    <Text style={styles.clubName}>Hello</Text>
                    <View style={styles.clubLitnessSection}>
                        <LinearGradient
                            colors={['#4930EC', '#7224B5', '#9B1881' ]}
                            start={[1, 0]}
                            style={styles.litnessGraphic}><Text style={styles.litnessRating}>4.9</Text>
                        </LinearGradient>
                    </View>
                </View>
                <View style={styles.hoursView}>
                    <Text style={styles.openStatusText}>Open</Text>
                    <Text style={styles.openTimesText}>4:00pm - 9:00pm</Text>
                </View>
                <View style={styles.clubRow}>
                    <TouchableHighlight style={styles.reviewButton}>
                        <View style={styles.reviewButton}><Text style={styles.buttonText}>Posts</Text></View>
                    </TouchableHighlight>
                    <View style={styles.spacer}></View>
                    <TouchableHighlight style={styles.directionsButton}>
                        <View style={styles.directionsButton}><Text style={styles.buttonText}>Directions</Text></View>
                    </TouchableHighlight>
                </View>
            </View>
        </View>
    )
  }

export default DetailsScreen