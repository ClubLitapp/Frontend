import React from "react";
import { View, Text, StatusBar, StyleSheet, TouchableHighlight, Image } from "react-native";
import { FlashList } from "@shopify/flash-list";
import { LinearGradient } from "expo-linear-gradient/build/LinearGradient";

const StoriesData = [
  {
    title: "First Item",
  },
  {
    title: "Second Item",
  },
  {
    title: "First Item",
  },
  {
    title: "Second Item",
  },
  {
    title: "First Item",
  },
  {
    title: "Second Item",
  },
  {
    title: "First Item",
  },
  {
    title: "Second Item",
  },
  {
    title: "First Item",
  },
  {
    title: "Second Item",
  },
  {
    title: "First Item",
  },
  {
    title: "Second Item",
  },
  {
    title: "First Item",
  },
  {
    title: "Second Item",
  },
];

styles = StyleSheet.create({
  list:{
    height: 72,
    width: '100%'
  },
  StoryView:{
    height: 72, 
    width: 72,
    borderRadius: 38,
  },
})

const StoryButton = ({active, onPress, item}) => {
  return (<TouchableHighlight onPress={onPress}>
    <Image style={styles.StoryView} source={require('../../assets/image.jpg')}/>
  </TouchableHighlight>)
}
const Stories = ({onPress}) => {
  return (
    <View style={styles.list}>
      <FlashList
            data={StoriesData}
            renderItem={({ item }) => <StoryButton active={true} item={item} onPress={onPress}/>}
            estimatedItemSize={200}
            horizontal={true}
            ItemSeparatorComponent={() => <View style={{width: 12}} />}
          />
    </View>
    
  );
};

export default Stories