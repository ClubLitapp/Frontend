import React from 'react'
import {View, Text, Image, StyleSheet} from 'react-native'

const styles = StyleSheet.create({
    header: {
        height: 45,
        flexDirection: 'row',
        alignContent: 'center',
        color: "black"
    },
    appIcon:{
        height: 45,
        width: '100%',
        resizeMode: 'contain'
    },
 })

const Header = () => {
    return (<View style={styles.header}>
            <Image style={styles.appIcon} source={require('../../assets/clublit.png')} />
        </View>)
}   

export default Header