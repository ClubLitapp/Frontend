import React from 'react'
import {Pressable, View, Image, Text, ImageBackground, TouchableHighlight} from 'react-native'
import { LinearGradient } from 'expo-linear-gradient'
import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    listItem: {
        backgroundColor: '#1F1F1F',
        height: 192,
        borderRadius: 16,
        flexDirection: 'column',
    },
    clubSection: {
        flex: 1,
        color: 'white',
        flexDirection: 'column'
    },
    clubName:{
        fontWeight: 'bold',
        color: 'white',
        textAlignVertical: 'top',
        fontSize: 24,
        marginRight: 8,
        alignSelf: 'center'
    },
    litnessGraphic: {
        borderRadius: 5,
        width: 32,
        flexDirection: 'column'
    },
    litnessRating: {
        fontWeight: 'bold',
        color: 'white',
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: 16
    },
    clubLitnessSection:{
        flexDirection: 'row',
        alignSelf: 'center'
    },
    clubData:{
        flexDirection: 'column',
        width: '100%',
        height: '100%',
        paddingHorizontal: 16,
        justifyContent: 'flex-end'
    },
    clubIcon:{
        height: '100%',
        width: '100%',
        resizeMode: 'cover',
        borderRadius: 16,
        flexDirection: 'row',
        justifyContent: 'flex-end'
    },
    favoriteView:{
        height: 64,
        width: 64,
        position: 'absolute',
        alignSelf: 'flex-start',
    },
    clubDataRow:{
        width: '100%',
        height: '25%', 
        flexDirection: 'row',
    }
    });

    
const Item = ({title, rating, imageURL, onPress}) => (
    <TouchableHighlight style={styles.listItem} 
      onPress={onPress}>
        <View style={styles.clubSection}>
            <ImageBackground style={styles.clubIcon} source={require('../../assets/image.jpg')} imageStyle={{ borderRadius: 16}}>
                <View style={styles.clubData}>
                    <View style={styles.clubDataRow}>
                        <Text style={styles.clubName}>{title}</Text>
                        <View style={styles.clubLitnessSection}>
                            <LinearGradient
                                colors={['#4930EC', '#7224B5', '#9B1881' ]}
                                start={[1, 0]}
                                style={styles.litnessGraphic}><Text style={styles.litnessRating}>{rating}</Text>
                            </LinearGradient>
                        </View>
                    </View>
                </View>
            </ImageBackground>
          </View>
    </TouchableHighlight>
  );

  export default Item