import React from "react"
import { FlatList, View } from "react-native"
import PressFilter from "./HomeScreen-Filter"

const FILTERS = [
    {
      id: 0,
      type: 'Open',
      enabled: true
    }
  ]
  const styles = StyleSheet.create({
    filterList: {
        height: 56
    },
  });


const FilterBar = () => {
    <FlatList
          data={filterList}
          renderItem={({item}) => <PressFilter onPress={()=>{
            const updatedList = filterList.map(it => it.id == item.id ? {...it, enabled: !it.enabled} : it)
            setFilterList(updatedList)
          }} enabled={item.enabled} text={item.type}/>}
          horizontal = {true}
          ItemSeparatorComponent={() => <View style={{width: 8}} />}
          style={styles.filterList}>
    </FlatList>
}

export default FilterBar