import React from "react";
import { StyleSheet, Text , TouchableHighlight} from "react-native";
import { View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
const styles = StyleSheet.create({
    navHolder:{
        width: '100%',
        height: '100%',
        position: 'absolute',
        justifyContent: 'flex-end',
        alignSelf: 'flex-end'
    },
    navbarView:{
        height: 64,
        flexDirection: 'row',
        justifyContent: "center",
        alignSelf: 'center'
    },
    locationHolder:{
        height: 64,
        width: 192,
        borderTopLeftRadius: 16,
        borderTopRightRadius: 16,
        backgroundColor: 'black',
        position: 'absolute',
        borderWidth: 0.4,
        borderRightColor: 'grey',
        borderLeftColor: 'grey',
        borderTopColor: 'grey',
        flexDirection: 'column',
        justifyContent: 'center'
    },
    touchable:{
        height: 64,
        width: 192,
        borderTopLeftRadius: 16,
        borderTopRightRadius: 16,
        backgroundColor: 'black',
        position: 'absolute',
        flexDirection: 'column',
        justifyContent: 'center'
    },
    navbarBackground:{
        height: 56,
        width: '100%',
        backgroundColor: 'black',
        alignSelf: 'flex-end',
        borderTopColor: 'grey',
        borderWidth: 0.2,
        justifyContent: 'space-evenly'
    },
    locationText:{
        color: 'white',
        textAlignVertical: 'center',
        fontSize: 28,
        marginRight: 8,
        alignSelf: 'center'
    },
    zipcodeText:{
        color: 'white',
        textAlignVertical: 'center',
        fontSize: 16,
        marginRight: 8,
        alignSelf: 'center'
    },
    spacer:{
        width: 192
    },
    navButton:{
        height: 56,
        flex: 1,
    }
})
const NavigationBar = (s) => {
    return (
        <View style={styles.navHolder}>
            <View style={styles.navbarView}> 
                <View style={styles.navbarBackground}>
                    <View style={styles.navButton}>
                        
                    </View>
                    <View style={styles.spacer}/>
                    <View style={styles.navButton}>

                    </View>
                </View>
                <TouchableHighlight onPress={()=>{}} style={styles.touchable}>
                    <LinearGradient
                    colors={['#9B1881', '#7224B5', '#4930EC']}
                    start={[1, 0]}
                    style={styles.locationHolder}>
                        <Text style={styles.locationText}>Miami</Text>
                        <Text style={styles.zipcodeText}>11435</Text>
                    </LinearGradient>
                </TouchableHighlight>
            </View>
        </View>
        
    )
}

export default NavigationBar