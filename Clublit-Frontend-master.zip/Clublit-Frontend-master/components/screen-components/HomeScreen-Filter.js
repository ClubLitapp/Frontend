import React from 'react'
import {Pressable, View, Image, Text, TouchableHighlight} from 'react-native'
import { LinearGradient } from 'expo-linear-gradient'
import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    filterItem: {
        backgroundColor: '#1F1F1F',
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 16,
    },
    filterText: {
        color: 'white',
        textAlign: 'center',
        fontWeight: 'bold',
    },
});

const onEnabled = ({enabled, text}) =>  {
    if(enabled){
        return (<LinearGradient                  
            colors={['#9B1881', '#7224B5', '#4930EC']}
            start={[1, 0]} 
            style={styles.filterItem}>
            <Text style={styles.filterText}>{text}</Text>
        </LinearGradient>)
    }
    else
    {
        return (<View style={styles.filterItem}>
            <Text style={styles.filterText}>{text}</Text>
        </View>)
    }
}
const PressFilter = ({text, enabled, onPress}) => (
    <TouchableHighlight onPress={onPress}>
        <LinearGradient                  
            colors={enabled ? ['#9B1881', '#7224B5', '#4930EC'] : ['#1F1F1F', '#1F1F1F']}
            start={[1, 0]} 
            style={styles.filterItem}>
            <Text style={styles.filterText}>{text}</Text>
        </LinearGradient>
    </TouchableHighlight>
  );

  export default PressFilter
